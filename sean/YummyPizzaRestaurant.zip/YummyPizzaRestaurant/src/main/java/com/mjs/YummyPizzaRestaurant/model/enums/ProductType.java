package com.mjs.YummyPizzaRestaurant.model.enums;

public enum ProductType {
    pizza,
    addOn
}
