package com.mjs.YummyPizzaRestaurant.model.enums;

public enum PizzaSize {
    small,
    medium,
    large
}
