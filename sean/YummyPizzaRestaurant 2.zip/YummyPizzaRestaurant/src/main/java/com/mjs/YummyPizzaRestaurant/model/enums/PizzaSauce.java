package com.mjs.YummyPizzaRestaurant.model.enums;

public enum PizzaSauce {
    tomato,
    barbeque;
}
