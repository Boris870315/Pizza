package com.mjs.YummyPizzaRestaurant.model.enums;

public enum PizzaBase {
    traditional,
    wholemeal,
    glutenFree
}
